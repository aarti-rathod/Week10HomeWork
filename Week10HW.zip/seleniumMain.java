/**
 * Created by JANVI on 06/10/2019.
 */
public class seleniumMain {
    public static void main(String[] args) {

       mozilaTest a = new mozilaTest();
       a.runMozila();

      chromeTest objCh = new chromeTest();
      objCh.run();

       expTest objex= new expTest();
       objex.runExpT();

    }
}

